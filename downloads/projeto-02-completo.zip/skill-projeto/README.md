# TikTok Storyboard

Skill em português para análise assistida de vídeos de IA: [instruções](skills/tiktok-storyboard/SKILL.md).

Requisitos: Python 3.12, ffmpeg e ffprobe.

```sh
python -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/python skills/tiktok-storyboard/scripts/analyze.py 'https://www.tiktok.com/@autor/video/ID' --output /tmp/tiktok-analise --transcribe
```

Também aceita um arquivo local. Saídas: metadados, candidatos a cenas com três quadros por cena, pranchas JPEG e transcrição automática opcional. A skill orienta a revisão e produção do relatório final: cenas detectadas não equivalem a imagens originais recuperadas. Transcrição requer baixar um modelo Whisper; uma saída automática não garante exatidão.

TikTok pode bloquear downloads. Nesse caso, use um arquivo fornecido pelo usuário. Nenhum token é necessário para análise local. Não há serviço web para iniciar.
