#!/usr/bin/env python3
"""Extract evidence for agent-reviewed TikTok storyboards; never infer original assets."""
import argparse
import json
import os
from pathlib import Path
import re
import subprocess
from urllib.parse import urlparse


def run(args):
    return subprocess.run(args, check=True, capture_output=True, text=True).stdout


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('source', help='Public TikTok URL or local video')
    p.add_argument('--output', type=Path, required=True, help='New output directory')
    p.add_argument('--threshold', type=float, default=0.3)
    p.add_argument('--transcribe', action='store_true')
    p.add_argument('--model', default='small')
    p.add_argument('--language', default=None)
    a = p.parse_args()
    if not 0 < a.threshold < 1:
        p.error('threshold must be between 0 and 1')
    a.output.mkdir(parents=True, exist_ok=False)
    out = a.output.resolve()
    if a.source.startswith(('https://', 'http://')):
        u = urlparse(a.source)
        if u.scheme != 'https' or not (u.hostname == 'tiktok.com' or (u.hostname or '').endswith('.tiktok.com')):
            p.error('Use an HTTPS TikTok URL or a local file')
        import yt_dlp
        with yt_dlp.YoutubeDL({'outtmpl': str(out / 'source.%(ext)s'), 'noplaylist': True,
                              'merge_output_format': 'mp4', 'socket_timeout': 30,
                              'retries': 2, 'writesubtitles': True, 'writeautomaticsub': True,
                              'subtitleslangs': ['all']}) as dl:
            info = dl.extract_info(a.source, download=True)
            video = Path(dl.prepare_filename(info))
            if not video.exists():
                video = out / 'source.mp4'
            metadata = {k: info.get(k) for k in ('id', 'title', 'description', 'uploader', 'webpage_url', 'duration')}
    else:
        video = Path(a.source).resolve(strict=True)
        metadata = {'local_file': video.name}
    probe = json.loads(run(['ffprobe', '-v', 'error', '-show_format', '-show_streams', '-of', 'json', str(video)]))
    duration = float(probe['format']['duration'])
    # Scene transitions nominate boundaries, not the original image-to-video assets.
    detected = subprocess.run(['ffmpeg', '-hide_banner', '-i', str(video), '-an', '-vf',
                              f"select='gt(scene,{a.threshold})',showinfo", '-f', 'null', '-'],
                              capture_output=True, text=True, check=True)
    cuts = sorted(set(float(t) for t in re.findall(r'pts_time:([0-9.]+)', detected.stderr)))
    boundaries = [0.0] + [t for t in cuts if 0.1 < t < duration - 0.1] + [duration]
    frames = out / 'frames'
    frames.mkdir()
    scenes = []
    from PIL import Image, ImageOps, ImageDraw
    tiles = []
    for i, (start, end) in enumerate(zip(boundaries, boundaries[1:]), 1):
        samples = []
        for label, fraction in [('early', .1), ('middle', .5), ('late', .9)]:
            t = start + (end-start)*fraction
            target = frames / f'{i:03d}-{label}.jpg'
            run(['ffmpeg', '-v', 'error', '-ss', str(t), '-i', str(video), '-frames:v', '1', '-q:v', '2', str(target)])
            samples.append({'time': round(t, 3), 'file': str(target.relative_to(out))})
        scenes.append({'scene': i, 'start': start, 'end': end, 'samples': samples, 'anchor_status': 'candidate_requires_visual_review'})
        with Image.open(out / samples[1]['file']) as im:
            tile = Image.new('RGB', (240, 280), 'white')
            thumb = ImageOps.contain(im.convert('RGB'), (240, 250))
            tile.paste(thumb, ((240-thumb.width)//2, 0))
            ImageDraw.Draw(tile).text((5, 255), f'{i:03d} | {start:.2f}-{end:.2f}s', fill='black')
            tiles.append(tile)
    for page in range(0, len(tiles), 24):
        batch = tiles[page:page+24]
        sheet = Image.new('RGB', (240*4, 280*((len(batch)+3)//4)), '#ddd')
        for j, tile in enumerate(batch):
            sheet.paste(tile, ((j%4)*240, (j//4)*280))
        sheet.save(out / f'storyboard-{page//24+1:02d}.jpg')
    result = {'metadata': metadata, 'duration': duration, 'candidate_scene_count': len(scenes),
              'warning': 'Scene count is not original anchor count. Review samples and transitions visually.', 'scenes': scenes}
    (out / 'analysis.json').write_text(json.dumps(result, ensure_ascii=False, indent=2))
    if a.transcribe and any(s['codec_type'] == 'audio' for s in probe['streams']):
        # Cloud homes may be read-only. Set this before importing the model hub.
        os.environ.setdefault('HF_HOME', '/workspace/tiktok/.cache/huggingface')
        from faster_whisper import WhisperModel
        import numpy as np
        # Decode using the installed ffmpeg; avoids PyAV API version mismatches.
        pcm = subprocess.run(['ffmpeg', '-v', 'error', '-i', str(video), '-vn',
                              '-ar', '16000', '-ac', '1', '-f', 's16le', '-'],
                             capture_output=True, check=True).stdout
        audio = np.frombuffer(pcm, dtype=np.int16).astype(np.float32) / 32768
        segments, info = WhisperModel(a.model, device='cpu', compute_type='int8', cpu_threads=4).transcribe(audio, language=a.language)
        transcript = [{'start': s.start, 'end': s.end, 'text': s.text} for s in segments]
        (out / 'transcript.json').write_text(json.dumps({'status': 'automatic_unverified', 'language': info.language, 'segments': transcript}, ensure_ascii=False, indent=2))
        (out / 'transcript.txt').write_text('\n'.join(f"[{s['start']:.2f}-{s['end']:.2f}] {s['text']}" for s in transcript))
    elif a.transcribe:
        (out / 'transcript.txt').write_text('Vídeo sem faixa de áudio.\n')
    print(json.dumps({'output': str(out), 'candidate_scenes': len(scenes)}))


if __name__ == '__main__':
    main()
