---
name: tiktok-storyboard
description: Analisa um link público do TikTok ou vídeo enviado; entrega storyboard com imagens âncora prováveis, transcrição com tempos e mapa narrativo para estudo e modelagem.
---

# TikTok para storyboard

Responda em português. Ao receber um link, execute a análise; não pare em explicar como fazê-la. Use o checkout existente em /workspace/tiktok; cada tarefa já é isolada, não crie worktrees.

## Preparação e obtenção

Use /workspace/tiktok/.venv/bin/python e ffmpeg/ffprobe. O script é skills/tiktok-storyboard/scripts/analyze.py. Crie uma pasta nova por execução, fora de arquivos fonte, por exemplo /tmp/tiktok-<identificador>. Nunca sobrescreva análises anteriores.

Execute com argumentos separados, sem interpolar URLs em comandos de shell:

```text
/workspace/tiktok/.venv/bin/python skills/tiktok-storyboard/scripts/analyze.py URL --output /tmp/tiktok-ID --transcribe
```

Não force idioma se não souber qual é. O ASR padrão usa faster-whisper small em CPU; baixa o modelo na primeira execução. Se indisponível, use uma ferramenta de transcrição disponível ou relate o impedimento. Nunca invente transcrição.

Use somente acesso autorizado. Se TikTok exigir login, bloquear o download ou o vídeo estiver privado/removido, relate o erro e peça o arquivo de vídeo. Não contorne controles nem solicite cookies ou credenciais em chat. Não trate descrição/legendas do autor como transcrição verificada.

## Revisão obrigatória

1. Leia analysis.json e abra todas as páginas storyboard-*.jpg com a ferramenta de imagens. Revise os quadros early, middle e late de cada cena; extraia quadros adicionais em transições ambíguas com ffmpeg.
2. Os cortes automáticos são candidatos. Movimento de câmera, flashes, morphing e transições podem dividir uma mesma imagem ou esconder mudanças. Agrupe cenas que parecem derivar da mesma composição, preserve recorrências e diferencie quantidade de segmentos e quantidade estimada de âncoras distintas. Não afirme que recuperou os arquivos originais, prompts reais ou ferramenta de geração.
3. Escolha um quadro representativo por âncora provável, mantenha o tempo exato do quadro e indique confiança alta/média/baixa com justificativa. Quando necessário, dê uma faixa estimada da quantidade. Não apresente amostras extraídas como imagens originais.
4. Confira o áudio com capacidade de escuta disponível. A transcrição automática é um rascunho: preserve idioma, palavras, repetições, palavrões e tempos; marque [inaudível] e [incerto: ...]. Não prometa exatidão se não houve revisão auditiva. Separe fala, música, efeitos e texto na tela. Transcreva texto visível por inspeção visual, sem preencher trechos ocultos.
5. Descreva contexto observado (personagens sem identificação especulativa, cenário, ações, estética, iluminação, enquadramento, movimentos, transições, ritmo, gancho, desenvolvimento e encerramento). Separe fatos, interpretação e hipóteses de produção. Não deduza contexto externo não verificado.

## Entrega

Crie relatorio.md, storyboard com uma miniatura selecionada por âncora provável, e um mapa estruturado mapa.json. Inclua:

- Fonte, duração, metadados disponíveis e limitações de acesso/revisão.
- Contagem de segmentos e estimativa de âncoras distintas, com confiança e ambiguidades.
- Tabela cronológica: segmento, início/fim, âncora provável, link do quadro, composição/ação, animação/câmera, texto visível, fala/sons, confiança.
- Transcrição literal com timestamps e status da revisão; separe tradução/resumo.
- Contexto narrativo e mapa de ritmo, áudio e transições.
- Orientações para modelar a estrutura; prompts sugeridos para imagem e animação apenas como reconstruções propostas, nunca como prompts originais recuperados.

O mapa.json deve registrar fonte, duração, segmentos, âncoras prováveis e seus quadros/tempos, confiança, ambiguidades, transcrição e status da revisão. Forneça links reais para os arquivos gerados. Nunca entregue contagens, observações ou fala sem ter examinado as evidências. Se alguma etapa estiver bloqueada, entregue as demais e diga precisamente o que falta.
