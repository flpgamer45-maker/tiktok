# Projeto 02 — Selfie ao pôr do sol

Arquivo: `ssstik.io_1793126666067.mp4`. Duração: **15,046 segundos**. Resolução **360 × 662**, vertical, **24 fps**. Faixa de áudio AAC, 44,1 kHz, dois canais. Não foi fornecido link para esta publicação.

## Estimativa das imagens âncora

**1 composição âncora principal provável**, correspondente a **1 plano contínuo visível**. Não foram detectados cortes pelo detector com limiar 0,08; a revisão de 30 amostras a cada meio segundo e dos quadros inicial, intermediários e final é consistente com essa leitura. Isso não comprova uma única imagem de origem nem uma única geração: extensões e junções visualmente semelhantes podem não deixar cortes visíveis.

Confiança alta para a continuidade da composição observada; média para a hipótese operacional de uma imagem-base. A origem por IA não foi comprovada pelo arquivo final. Não há base para atribuir pessoa, ferramenta, modelo ou localização real.

## Storyboard

- **A01 — 00:00–00:15,05:** [quadro representativo](ancoras/A01.jpg), extraído em 00:00. Homem adulto de aparência madura, cabelo ondulado castanho e grisalho, barba curta grisalha, camisa de botões verde-oliva/castanha com bolsos e mangas curtas. Rosto e tronco em primeiro plano; braço no lado esquerdo da imagem estendido em direção à câmera, sugerindo selfie. Ao fundo: casa de pedra com telhado de telhas, vegetação, árvores altas estreitas, colinas, céu dourado e sol baixo à esquerda.
- **Animação observada por amostragem:** Nas amostras mudam abertura da boca, posição da cabeça, sobrancelhas, olhos e sorriso. O enquadramento e o fundo permanecem muito semelhantes. A leitura é de um plano frontal de fala para câmera, com pequenas oscilações. Não há evidência visual suficiente para dizer se houve uma única geração ou junções de clipes semelhantes.
- **Apoios de revisão, não novas âncoras:** 00:01,505, 00:07,523, 00:13,541 e último quadro em 00:14,958.
- **Texto em tela:** nenhum texto, legenda ou interface observados.

## Contexto observado

Uma figura masculina se dirige à pessoa que assiste como se tivesse visto sua foto. Faz uma observação afetiva e convida a pessoa a clicar junto à foto do perfil e escutar um áudio. O vídeo mostra somente o apresentador: a foto da destinatária, a interface do perfil e o áudio mencionado não aparecem. As afirmações pertencem ao roteiro; não foram verificadas como acontecimentos reais.

## Interpretação narrativa

A estrutura sugere aproximação afetiva: atenção individual aparente → elogio emocional → convite de baixa pressão → ação no perfil → reforço pessoal. A ausência de outros personagens mantém o foco na relação entre apresentador e espectador. A referência a “ela” sugere destinatária feminina no texto; não permite concluir idade, público real, relacionamento ou intenção comercial.

O jardim, a casa de pedra e a luz de fim de tarde podem reforçar uma impressão de tranquilidade e acolhimento. Essa é uma leitura estética, não evidência de que a pessoa viva ali ou esteja gravando em um país específico.

## Mapa de ritmo

As divisões abaixo são fases da fala, não cortes nem imagens diferentes. Os tempos vêm do reconhecimento e são aproximados.

| Início–fim | Função | Conteúdo | Âncora |
|---|---|---|---|
| 00:00.76–00:04.18 | Abordagem pessoal | Afirma estar olhando uma foto e decide falar com a pessoa. | A01 |
| 00:04.36–00:08.24 | Vínculo emocional | Atribui à pessoa uma sensação de paz e algo que não sentia há tempo. | A01 |
| 00:08.94–00:11.58 | Convite e ação | Condiciona o convite à vontade da pessoa e pede clique na “cruz” da foto. | A01 |
| 00:11.72–00:13.00 | Próximo conteúdo | Pede que a pessoa escute um áudio que teria deixado. | A01 |
| 00:13.38–00:14.68 | Fechamento pessoal | Diz querer que seja aquela pessoa ouvindo. | A01 |

## Transcrição com tempos

**Transcrição automática comparada entre Whisper medium e small; sem revisão auditiva humana. Tempos aproximados. Divergências marcadas; exatidão literal não certificada.** Os colchetes são notas de análise. Pontuação editorial.

- **00:00.76–00:02.40:** Oi, eu fiquei olhando [incerto: a] sua foto aqui.
- **00:02.52–00:04.18:** Aí pensei: [incerto: ah,] vou falar com ela.
- **00:04.36–00:06.04:** Porque, sei lá, você me passou uma paz.
- **00:06.56–00:08.24:** Faz tempo que eu não sentia isso quando vi alguém.
- **00:08.94–00:10.22:** Se você sentir vontade também,
- **00:10.46–00:11.58:** clica na cruz da minha foto,
- **00:11.72–00:13.00:** depois [incerto: escuta o áudio / escuto áudio] que eu deixei.
- **00:13.38–00:14.68:** Queria muito que fosse você ouvindo.

O medium reconheceu “olhando sua foto” e “depois escuta o áudio”; o small incluiu o artigo “a” e reconheceu “depois escuto áudio”. A presença do artigo e a segmentação de “escuta o/escuto” exigem escuta para certificação literal. “Ah” tem confiança menor no small. “Cruz” aparece nas duas saídas: não foi substituído por “botão de seguir”, pois a interface não está no vídeo.

## Direção visual e continuidade

- Personagem: manter cabelo, barba, camisa, abertura da gola, bolsos e braço na mesma posição geral.
- Câmera: selfie de tronco/rosto; olhar direcionado à lente, pequenas mudanças de expressão. O aparelho de gravação não é visível.
- Cenário: preservar casa à direita, sol baixo à esquerda e árvores altas; arquitetura evoca ambiente rural mediterrâneo, sem confirmação de país.
- Luz e cor: dourado/alaranjado no céu e pele, verdes na paisagem, camisa escura; contraste entre fundo quente e figura em primeiro plano.
- Movimento: priorizar fala e expressão; evitar novos gestos amplos que criem outro enquadramento.
- Som: fala em português reconhecida. Timbre, trilha e efeitos não foram classificados por escuta; a sincronização labial exata não foi validada.

## Prompts sugeridos de reconstrução

São propostas novas baseadas no que aparece, não os prompts originais. Use um personagem fictício e preserve a composição, sem alegar reproduzir uma pessoa identificada.

### Imagem

Retrato vertical fotorealista de um personagem adulto fictício, homem de aparência madura, cabelo ondulado com fios grisalhos, barba curta grisalha, camisa verde-oliva de botões com bolsos e mangas curtas, enquadramento de selfie do tronco para cima, um braço estendido em direção à câmera, olhar para a lente e sorriso discreto. Casa rural de pedra com telhas no lado direito, árvores altas estreitas, jardim verde e colinas ao fundo, pôr do sol dourado no alto esquerdo, luz quente com brilho de contorno no cabelo, detalhes naturais de pele, profundidade de campo moderada. Manter composição vertical próxima à referência; sem texto e sem interface de aplicativo.

### Animação

Partir da imagem-base A01 como referência de composição. Manter o mesmo personagem, camisa, braço em primeiro plano, posição do sol, casa e árvores. Criar um plano contínuo de aproximadamente 15 segundos de fala para a lente, com movimentos leves de cabeça, piscadas naturais, sorriso discreto e articulação de boca coerente com a fala em português revisada. Câmera em posição de selfie quase fixa, pequenas oscilações apenas. Sem cortes, sem trocar o cenário, sem deformar o rosto ou os dedos. Se a ferramenta não suportar a duração, usar extensões compatíveis e conferir a continuidade.

## Plano de modelagem

1. Prepare uma imagem-base A01 com o personagem fictício e a composição de selfie. O quadro extraído tem 360 × 662; não é uma imagem original de alta resolução e não foi apresentado como tal.
2. Revise a transcrição pelo áudio antes de gravar ou gerar a fala. Não use a divergência do ASR como texto definitivo.
3. Gere a animação como um plano único, ou use extensões da mesma composição. Quantidade de clipes depende da ferramenta e não pode ser inferida do original.
4. Faça sincronização labial com a fala revisada. Compare boca, olhos, barba, braço, camisa, telhado e árvores no início e no fim.
5. Mantenha a estrutura: abordagem pessoal → vínculo emocional → convite ao perfil/áudio → fechamento pessoal. Se adaptar a mensagem, trate como roteiro novo, não como transcrição original.
6. Na exportação, mantenha a proporção original ou faça um recorte deliberado para a plataforma; o arquivo recebido não é exatamente 9:16. Não prometa ganho de detalhe só por ampliar a resolução.

## Limitações e arquivos

Não foi recuperada imagem original de geração. O uso de IA, a identidade do homem, a localização e a origem da voz não foram confirmados. A foto da pessoa abordada e o áudio citado não estão no arquivo. Não foi verificada a publicação de origem. A transcrição é automática e exige revisão auditiva para garantir exatidão. Este projeto é separado da análise anterior das vizinhas.

O pacote inclui A01, quadros de apoio, pranchas de revisão, relatório, mapa JSON, transcrição TXT/SRT, saídas brutas dos dois modelos e cópia dos arquivos da skill. O vídeo enviado não será republicado no pacote.
